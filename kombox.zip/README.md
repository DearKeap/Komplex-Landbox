# Kombox — Bare-Minimum Scaffold

Ini BUKAN implementasi lengkap dari semua yang udah didesain (MetaMod, ModLoad/Luau,
netcode, Absolute Force, dst). Ini "game simpel jalan dulu" — world kecil (4x4 chunk,
64x16x64 block) dengan 5 tipe block (Grass/Dirt/Stone/Plank/Leaf, warna flat karena
belum ada texture — Axel nambahin sendiri belakangan), yang bisa dijalanin & dilihat.

Isinya:
- Window + GPU init (wgpu), render pipeline beneran (bukan cuma clear-color)
- World-gen sederhana — value noise deterministic (bukan multi-noise climate-based
  penuh), layering Stone/Dirt/Grass + pohon (Plank+Leaf) kadang muncul
- Mesher NAIVE (satu quad per face yang keliatan) — belum greedy meshing
- **Gravity + collision** — AABB pemain vs voxel, per-axis (X/Z/Y terpisah), jatuh
  & landing beneran, bisa lompat (`Space`, cuma kalau lagi di tanah)
- **Mouse-look** — cursor di-lock ke window, gerakin mouse buat noleh (raw delta,
  bukan posisi absolut), `Esc` buat lepas/kunci ulang cursor
- **Present mode uncapped** — coba `Immediate` dulu (bener-bener gak dibatesin),
  fallback `Mailbox`, baru `Fifo` (vsync) kalau dua itu gak didukung. FPS di-log
  ke console tiap detik buat verifikasi.
- Tick loop fixed-timestep, TERPISAH dari render loop — WASD/gravity/collision
  jalan di tick (deterministic), mouse-look update langsung tiap event (biar
  responsif independen dari tick rate)
- Palette-based chunk storage, plus `World` yang nyimpen data chunk MENTAH
  (bukan cuma mesh GPU) biar bisa di-query buat collision
- Hook primitif generik (register/fire, skeleton MetaMod nanti)

## Kenapa cuma ini

Kode ini ditulis TANPA akses internet dan TANPA bisa di-compile/dites di sisi saya
(sandbox saya gak bisa fetch crate dari crates.io). Jadi ada kemungkinan nyata ada
typo kecil atau API call yang gak persis cocok sama versi crate yang ke-resolve
pas lo `cargo build` — terutama di `src/main.rs` bagian setup wgpu Surface, karena
itu API yang paling sering berubah antar versi wgpu.

## Cara build

```bash
cargo build
cargo run
```

Titik paling rawan salah versi, urut dari yang paling mungkin:

1. **`create_surface`/`SurfaceConfiguration`** di `main.rs` — API wgpu paling sering
   berubah di sini
2. **`entry_point: "vs_main"`** di `render.rs` — beberapa versi wgpu lebih baru minta
   ini dibungkus `Some("vs_main")`
3. **Keyboard API** di `main.rs` (`PhysicalKey::Code`, `KeyCode::KeyW`, dst) — ini API
   winit yang relatif baru (0.29+), kalau resolve ke winit lebih lama, field/enum-nya beda
4. **`CursorGrabMode::Locked`** — gak semua platform dukung ini (kode udah fallback ke
   `Confined` otomatis kalau `Locked` gagal, tapi kalau dua-duanya gak didukung driver
   tertentu, cursor gak bakal ke-lock — game tetep jalan, cuma mouse-look gak berfungsi)
5. **`DeviceEvent::MouseMotion`** — di sebagian platform/driver butuh window fokus dulu
   sebelum device event mulai ke-kirim; kalau mouse-look gak respon, klik window dulu

Kalau ketemu compile error, jalanin `cargo tree | grep -E "wgpu|winit"` buat liat versi
persis yang ke-resolve, terus cocokin ke contoh resmi:
- https://github.com/gfx-rs/wgpu/tree/trunk/examples
- https://github.com/rust-windowing/winit/tree/master/examples

## Struktur

```
src/
├── main.rs           — entry point: init GPU, generate world, cursor grab, render+tick loop
├── camera.rs          — mouse-look + gravity/collision (AABB vs voxel)
├── render.rs           — Vertex, mesher naive, render pipeline (shader/buffer/depth)
├── shader.wgsl         — vertex-color shader (belum texture)
├── tick.rs             — TickClock fixed timestep + TickRate (Potato/Rice/Chicken/Beef)
├── hook.rs             — HookRegistry (register_hook/fire_hook primitif)
└── world/
    ├── mod.rs          — struct World (nyimpen ChunkSection mentah + query collision)
    ├── chunk.rs        — ChunkSection (palette-compressed) + 5 block type + warna
    └── worldgen.rs     — value noise terrain gen + penempatan pohon
```

## Kontrol

`W`/`A`/`S`/`D` jalan (relatif arah pandang, datar — noleh atas/bawah gak ngaruh ke
kecepatan jalan), gerakin **mouse** buat noleh, `Space` lompat (cuma kalau lagi
napak tanah), `Esc` lepas/kunci ulang cursor.

## Langkah berikutnya yang realistis (belum ada di sini)

1. **Texture** — ganti `block_color()` flat-color jadi UV lookup ke texture array
   (Axel udah bilang mau nambahin texture sendiri)
2. **Greedy meshing** — mesher sekarang naive (satu quad per face), belum digabung
   jadi quad besar sesuai desain
3. **Break/place block** — belum ada raycast dari kamera buat pilih block, belum ada
   interaksi klik kiri/kanan
4. **World lebih besar / infinite** — sekarang cuma grid 4x4 chunk fixed, belum ada
   chunk loading/unloading dinamis; collision juga masih query per-block naive
   (`is_solid_at` loop 3D), belum ada spatial optimization
5. `mlua`/Luau embedding buat ModLoad
6. ECS beneran (bisa pakai `hecs`/`bevy_ecs`, atau tulis sendiri)
7. Networking (`quinn` buat QUIC, sesuai desain netcode) — perlu diinget: gravity
   udah dihitung di tick loop fixed-timestep, jadi udah "siap" secara struktur buat
   nanti disinkronkan/direkonsiliasi ala client-prediction, walau belum ada network-nya

Test unit yang ada (`cargo test`) nutup `hook.rs` dan `world/chunk.rs` +
`world/worldgen.rs` (termasuk cek determinism: seed sama = hasil sama) — semua
bisa diverifikasi bener tanpa perlu jalanin GUI.
